package General;

class Hospital {
	void emergencyService() {
		System.out.println("Hospital Emergency Service");
	}

}

class CityHospital extends Hospital {
	void emergencyService() {
		super.emergencyService();
		System.out.println("CityHospital Emergency Service");
	}

}

public class Question16 {

	public static void main(String[] args) {
		CityHospital hosp = new CityHospital();
		hosp.emergencyService();

	}

}
