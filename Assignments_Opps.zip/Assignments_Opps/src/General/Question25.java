package General;

class School {
	String name;

	School(String name) {
		this.name = name;
		System.out.println("Name of the School is " + name);
	}

	void display() {
		System.out.println("This School is based out of Kolkata");
	}
}

public class Question25 {

	public static void main(String[] args) {
		School message = new School("Vivekananda Public School");
		message.display();

	}

}
