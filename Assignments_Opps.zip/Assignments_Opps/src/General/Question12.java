package General;

class Account {

	private String accountHolderName;
	private double balance;

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String name) {
		this.accountHolderName = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		if (balance >= 0) {
			this.balance = balance;
		} else {
			System.out.println("Balance cannot be negative.Roll back update");
		}
	}

	public void displayAccountInfo() {
		System.out.println("Holder: " + accountHolderName + " | Balance: " + balance);
	}
}

public class Question12 {

	public static void main(String[] args) {
		Account myAccount = new Account();

		myAccount.setAccountHolderName("Pranav V");
		myAccount.setBalance(5000);
		myAccount.displayAccountInfo();

		myAccount.setBalance(-100.0);
		myAccount.displayAccountInfo();
	}

}
