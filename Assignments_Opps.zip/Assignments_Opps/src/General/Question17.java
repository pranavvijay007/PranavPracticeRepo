package General;

abstract class Employee2 {

	String name;

	Employee2(String name) {
		this.name = name;

	}

	abstract void calculateSalary();

	void employeeDetails() {
		System.out.print("Name: " + name);
	}
}

class FullTimeEmployee extends Employee2 {
	double monthlySalary = 35000;

	FullTimeEmployee(String name) {
		super(name);
	}

	void calculateSalary() {

		System.out.println(" / Monthy salary is: " + monthlySalary);

	}

}

class PartTimeEmployee extends Employee2 {
	int daysWorked;
	double daillywage = 500;

	PartTimeEmployee(String name, int daysWorked) {
		super(name);
		this.daysWorked = daysWorked;
	}

	void calculateSalary() {
		double salary = daysWorked * daillywage;
		System.out.println(" / Salary is: " + salary);
	}
}

public class Question17 {

	public static void main(String[] args) {
		Employee2 ft = new FullTimeEmployee("Pranav");
		Employee2 pt = new PartTimeEmployee("Abhi", 15);

		ft.employeeDetails();
		ft.calculateSalary();

		pt.employeeDetails();
		pt.calculateSalary();

	}

}
