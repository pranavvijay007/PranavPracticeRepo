package General;

class Bank {

	final String IFSC = "BANK12345";

	final void showIFSC() {
		System.out.println("The Bank IFSC code is: " + IFSC);
	}
}

class HDFCBank extends Bank {

	void showIFSC() {
		System.out.println("HDFC IFSC code is: HDFC1234");
	}
}

public class Question9 {

	public static void main(String[] args) {
		HDFCBank myBank = new HDFCBank();

		myBank.showIFSC();
	}
}
