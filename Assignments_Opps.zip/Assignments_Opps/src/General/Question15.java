package General;

class LoanCalculator {

	void calculateLoan(int amount) {
		System.out.println("Loan amount is: " + amount);
	}

	void calculateLoan(int amount, double interestRate) {
		System.out.println("Loan amount is: " + amount + " / Interest rate is: " + interestRate);
	}
}

public class Question15 {

	public static void main(String[] args) {

		LoanCalculator lc = new LoanCalculator();
		lc.calculateLoan(5000);
		lc.calculateLoan(10000, 7.2);

	}

}
