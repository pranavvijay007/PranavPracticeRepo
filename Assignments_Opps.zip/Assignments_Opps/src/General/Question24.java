package General;

class Shape2 {
	int length;
	double pi = 3.14;

	Shape2(int length) {
		this.length = length;
	}

	void square() {
		System.out.println("Area of a sqaure have l=" + length + " is " + length * length);
	}

	void rectangle(int breadth) {
		System.out.println("Area of a rectangle have l=" + length + " and b=" + breadth + " is " + length * breadth);
	}

	void circle() {
		System.out.println("Area of a circle with r=" + length + " is " + length * length * pi);
	}
}

public class Question24 {

	public static void main(String[] args) {
		Shape2 area = new Shape2(5);
		area.square();
		area.rectangle(6);
		area.circle();

	}

}
