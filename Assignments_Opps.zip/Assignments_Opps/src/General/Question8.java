package General;

class Shape {

	void area() {
		System.out.println("Area of the Shape");
	}
}

class Rectangle extends Shape {

	void area() {
		System.out.println("Area of Rectangle");
	}
}

class Circle extends Shape {
	void area() {
		System.out.println("Area of Circle");
	}
}

public class Question8 {
	public static void main(String[] args) {

		Shape myShape;

		myShape = new Rectangle();
		myShape.area();

		myShape = new Circle();
		myShape.area();
	}

}
