package General;

abstract class Animal {

	abstract void sound();

}

class Dog extends Animal {

	void sound() {
		System.out.println("Dog: Woof Woof");
	}
}

class Cat extends Animal {

	void sound() {
		System.out.println("Cat: Meow Meow");
	}
}

public class Question5 {

	public static void main(String[] args) {

		Animal myDog = new Dog();
		Animal myCat = new Cat();

		myDog.sound();
		myCat.sound();

	}
}
