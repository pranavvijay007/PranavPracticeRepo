package General;

class Mall {
	String mallName;
	String place;

	Mall() {
		System.out.println("Welcome to the Mall");
	}

	Mall(String mallName, String place) {
		this();
		this.mallName = mallName;
		this.place = place;

		System.out.println("Welcome to the " + mallName + " Mall at " + place);

	}
}

public class Question23 {

	public static void main(String[] args) {

		// Mall mall1= new Mall() ;

		Mall mall2 = new Mall("Lulu", "Kochi");

	}

}
