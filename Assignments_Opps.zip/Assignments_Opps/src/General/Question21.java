package General;

class University {
	static String country = "India";
	String universityName;

	public University(String universityName) {
		this.universityName = universityName;

	}

	void display() {
		System.out.println("University : " + universityName + " located at " + country);
	}
}

public class Question21 {

	public static void main(String[] args) {
		University ref1 = new University("Kerala university");
		ref1.display();
		University ref2 = new University("Delhi university");
		ref2.display();

	}

}
