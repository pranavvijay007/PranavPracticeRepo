package General;

class Vehicle {
	void fuelType() {
		System.out.println("Runs on fuel");
	}
}

class ElectricCar extends Vehicle {

	void fuelType() {
		System.out.println("Runs on electricity");
	}

//    void run () {
//    	fuelType();
//    	super.fuelType();
//    }
}

public class Assignments2 {

	public static void main(String[] args) {

		Vehicle obj1 = new Vehicle();
		// ElectricCar obj2 = new ElectricCar();
		Vehicle obj2 = new ElectricCar();

		System.out.print("Vehicle: ");
		obj1.fuelType();

		System.out.print("ElectricCar: ");
		obj2.fuelType();

	}
}
