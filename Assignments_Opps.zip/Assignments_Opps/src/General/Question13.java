package General;

class Device {
	void start() {
		System.out.println("Device");
	}
}

class Mobile extends Device {
	void calling() {
		System.out.println("Mobile");
	}
}

class SmartPhone extends Mobile {
	void internet() {
		System.out.println("SmartPhone");
	}
}

public class Question13 {

	public static void main(String[] args) {

		SmartPhone myPhone = new SmartPhone();
		myPhone.start();
		myPhone.calling();
		myPhone.internet();

	}

}
