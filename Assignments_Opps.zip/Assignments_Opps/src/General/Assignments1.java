package General;

 class Employee {
	
	    private int empId;
	    private String empName;
	    private double salary;

	    
	    public int getEmpId() {
	        return empId;
	    }
	    public void setEmpId(int empId) {
	        this.empId = empId;
	    }

	   
	    public String getEmpName() {
	        return empName;
	    }
	    public void setEmpName(String empName) {
	        this.empName = empName;
	    }

	   
	    public double getSalary() {
	        return salary;
	    }
	    public void setSalary(double salary) {
	        this.salary = salary;
	        }
	   

	    
	    public void displayDetails() {
	        System.out.println("--- Employee Details ---");
	        System.out.println("ID: " + empId);
	        System.out.println("Name: " + empName);
	        System.out.println("Salary: " + salary);
	    }
	}

	public class Assignments1 {
	    public static void main(String[] args) {
	        Employee emp = new Employee();

	       
	        emp.setEmpId(423);
	        emp.setEmpName("Pranav V");
	        emp.setSalary(35000);
	        emp.displayDetails();
	 
	    }
	}

