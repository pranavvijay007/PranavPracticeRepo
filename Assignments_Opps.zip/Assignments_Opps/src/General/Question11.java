package General;

class Library {

	String libraryName;

	public Library() {
		System.out.println("Welcome to the Library!");
	}

	public void showLocation() {
		System.out.println("This library is located in Mumbai.");
	}
}

public class Question11 {

	public static void main(String[] args) {

		Library myLib = new Library();
		myLib.showLocation();

	}
}