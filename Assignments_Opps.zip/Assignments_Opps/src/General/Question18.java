package General;

interface Transport {
	void booking();
}

class Bus implements Transport {
	public void booking() {
		System.out.println("Bus ticket booked");

	}
}

class Flight implements Transport {
	public void booking() {
		System.out.println("Flight ticket booked");

	}
}

public class Question18 {

	public static void main(String[] args) {
		Transport ticket;

		ticket = new Bus();
		ticket.booking();

		ticket = new Flight();
		ticket.booking();
	}

}
