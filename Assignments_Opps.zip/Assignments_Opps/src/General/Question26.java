package General;

class School2 {
	String name;
	String address;
	String strength;

	School2(String name, String address) {
		this.name = name;
		this.address = address;
		this.strength = "not requred";
	}

	School2(String name, String address, String strength) {
		this(name, address);
		this.strength = strength;
	}

	void display() {
		System.out.println("Name of the school is " + name);
		System.out.println("Address of the school is " + address);
		System.out.println("Strength of the school is " + strength);
		System.out.println("----------------------------------------------------------");
	}
}

public class Question26 {

	public static void main(String[] args) {
		School2 obj1 = new School2("Vivekananda Public School", "Kolkata");
		obj1.display();

		School2 obj2 = new School2("MG Public School", "Delhi", "598");
		obj2.display();
	}

}
