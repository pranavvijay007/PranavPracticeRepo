package General;

class Calculator {

	static int add(int a, int b) {
		return a + b;
	}

	static double add(double a, double b) {
		return a + b;
	}
}

public class Question4 {

	public static void main(String[] args) {

		System.out.println(Calculator.add(12, 56));
		System.out.println(Calculator.add(12.55, 78.369));

	}

}
