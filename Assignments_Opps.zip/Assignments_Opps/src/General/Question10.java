package General;

class Student5 {
	 
	static String collegeName= "SNC";
	String name;
	int rollNo;
	
	Student5(String name, int rollNo){
		this.name=name ;
		this.rollNo=rollNo;		
	}
	
	void display()
	{
		System.out.println("Name: "+name+"/ RollNo:  "+rollNo+ "/  CollageName: "+collegeName);
	}
}

public class Question10 {

	public static void main(String[] args) {
		Student5 obj1=new Student5("Abhi", 1);
		obj1.display();
		Student5 obj2=new Student5("Pranav", 2);
		obj2.display();
		Student5 obj3=new Student5("Rafi", 3);
		obj3.display();
		Student5 obj4=new Student5("Shaan", 4);
		obj4.display();
	}
}
