package General;

class Product {
	int productId;
	String productName;
	double price;

	public Product() {
		System.out.println("Product Created ");
//        this.productId=productId ;
//        this.productName = productName;
//        this.price =price;
	}

	public Product(int productId, String productName, double price) {
		this.productId = productId;
		this.productName = productName;
		this.price = price;
	}

	public void displayProduct() {
		System.out.println("ID: " + productId);
		System.out.println("Name: " + productName);
		System.out.println("Price: $" + price);
		System.out.println("---------------------------");
	}
}

public class Question3 {

	public static void main(String[] args) {

		Product p1 = new Product();
		p1.displayProduct();

		Product p2 = new Product(101, "Smartphone", 699.99);
		p2.displayProduct();

	}
}
