package General;

class Camera {
	void capture() {
		System.out.println("Camera used to capture picture");
	}
}

class DSLCamera extends Camera {
	void capture() {
		System.out.println("DSLR didn't have any film");
	}
}

public class Question19 {

	public static void main(String[] args) {

		Camera ref = new DSLCamera();
		ref.capture();
	}

}
