package General;

class GovernmentRules {
	final int MAX_WORKING_HOURS = 8;

	void display() {
		System.out.println("Maximum working hours allowed is " + MAX_WORKING_HOURS);
	}
}

public class Question22 {

	public static void main(String[] args) {
		GovernmentRules gr = new GovernmentRules();
		gr.display();
		gr.MAX_WORKING_HOURS=12;

	}

}
