package General;

class Course {
	void courseInfo() {
		System.out.println("This is a general educational course.");
	}
}

class Science extends Course {
	void display1() {
		System.out.println("Included Science subjects");
	}
}

class Commerce extends Course {
	void display2() {
		System.out.println("Included Commerce subjects");
	}
}

class Arts extends Course {
	void display3() {
		System.out.println("Included Arts subjects");
	}
}

public class Question14 {

	public static void main(String[] args) {
		Science obj1 = new Science();
		obj1.courseInfo();
		obj1.display1();

		Commerce obj2 = new Commerce();
		obj2.courseInfo();
		obj2.display2();

		Arts obj3 = new Arts();
		obj3.courseInfo();
		obj3.display3();

	}

}
